﻿using Microsoft.AspNetCore.Mvc;

namespace SimplePostService.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class PostController : ControllerBase
    {
        [HttpPost]
        public IActionResult Post([FromBody] string data)
        {
            // Handle the posted data
            // For simplicity, we're just returning the received data
            return Ok($"Received data: {data}");
        }
    }
}
